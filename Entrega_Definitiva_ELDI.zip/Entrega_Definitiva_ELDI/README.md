# Analizador FFT en FPGA · Proyecto final ELDI

**Carlos Jose Castiblanco y Jarid Camilo Ojeda**  
Escuela Colombiana de Ingeniería Julio Garavito · Electrónica Digital

El proyecto principal es la variante con logo ampliado. Digitaliza AIN1 del AD7606 a 200 kS/s, calcula una FFT de 256 puntos y muestra la señal temporal o el espectro en HDMI 720p60. S2 cambia de vista. El modo Parallel Byte y S2 fueron aceptados por el profesor, según la confirmación de los estudiantes.

## Archivos de la entrega

| Carpeta | Contenido |
|---|---|
| [Gowin](Gowin/) | Proyecto `tang20k_presentacion_eldi_fd73.gprj`, HDL, restricciones y compilación reproducible. |
| [Programar](Programar/) | `ELDI_Analizador_FFT.fs`, bitstream principal listo para SRAM. |
| [Simulacion](Simulacion/) | `Design.txt` y `Testbench.txt`, paneles para EDA Playground. |
| [Informe](Informe/) | Informe IEEE en LaTeX y PDF, con las imágenes que usa el informe. |

## Montaje y alimentación

Usa una Tang Nano 20K (GW2AR-LV18QN88C8/I7), el módulo AD7606, una fuente externa de 5 V para el ADC, generador y monitor HDMI. Cablea con ambas placas apagadas. En la Tang, mira la cara de componentes con USB-C arriba y HDMI abajo. J6 queda a la izquierda y J5 a la derecha. Cuenta desde el USB-C. En el ADC, mira con la bornera verde a la izquierda, el texto AD7606 arriba y la cabecera digital a la derecha. Cuenta las filas de arriba abajo.

| AD7606 | Cabecera ADC | Pin FPGA | Tang |
|---|---|---:|---|
| D0 | 8 derecha | 27 | J6-8 |
| D1 | 8 izquierda | 28 | J6-9 |
| D2 | 7 derecha | 29 | J6-12 |
| D3 | 7 izquierda | 30 | J6-13 |
| D4 | 6 derecha | 31 | J6-14 |
| D5 | 6 izquierda | 77 | J6-5 |
| D6 | 5 derecha | 41 | J5-6 |
| D7 | 5 izquierda | 42 | J5-5 |
| BUSY | 10 izquierda | 48 | J5-10 |
| FD / FRSTDATA | 9 izquierda | 73 | J6-1 |
| CA / CONVST | 12 derecha | 15 | J6-6 |
| RD | 11 izquierda | 16 | J6-7 |
| CS | 10 derecha | 17 | J6-15 |
| RST | 11 derecha | 18 | J6-18 |
| GND | 9 derecha o 15 izquierda | — | J6-20, J5-2 o J5-15 |

- Alimenta la FPGA por USB-C y el módulo por su entrada de 5 V. Une las tierras del ADC, la FPGA, la fuente y el generador. Mantén separados los positivos de alimentación.
- Conserva la configuración lógica de 3,3 V del montaje confirmado. D15 alto selecciona Parallel Byte y D14 alto selecciona MSB primero. Mantén RANGE bajo para ±5 V y OS2:OS0 en 000. Los contactos J6-19 y J5-16 permiten fijar D14/D15 como niveles lógicos. CA y CB están unidos en este módulo.
- Conecta el generador a AIN1, segundo contacto de la bornera, con retorno al GND analógico. Lleva las entradas analógicas sin uso a GND. El monitor se conecta al HDMI de la placa.

## Programación y uso

1. En Gowin Programmer, detecta el dispositivo y el cable USB/JTAG. Selecciona **SRAM Program** y carga [ELDI_Analizador_FFT.fs](Programar/ELDI_Analizador_FFT.fs). La carga se pierde al apagar la FPGA.
2. Para verificar la pantalla, conecta AIN1 a GND con el generador desconectado. En la vista temporal se espera una línea centrada.
3. Aplica a AIN1 una senoide de **3125 Hz**, **2 Vpp**, offset **0 V** y ajuste de carga **High Z**. Se esperan cuatro períodos en pantalla y un pico dominante en el bin 4 al pulsar S2. La separación entre bins es 781,25 Hz. La magnitud es lineal y se grafica como módulo de FFT/256 en códigos de ADC.
4. S2 alterna las vistas al iniciar el cuadro siguiente. S1 reinicia el diseño y limpia el primer código retenido. Evita mantener S1 o S2 pulsado al encender o programar. LED5 indica la vista FFT y LED4 indica un fallo retenido.

Las ocho casillas debajo de los nombres muestran el código por la cantidad de casillas rojas.

| Rojas | Significado |
|---:|---|
| 0 | Sin causa retenida |
| 1 | BUSY no subió después de CONVST |
| 2 | BUSY no bajó dentro del límite |
| 3 | FRSTDATA no estaba alto al leer V1 |
| 4 | BUSY volvió a alto durante la lectura |
| 5 | El lector no quedó listo para el siguiente período |
| 6 | Sobrecarga de captura |
| 7 | Fallo de control de FFT o procesador |
| 8 | Error de protocolo del búfer de visualización |

## Recompilar en Gowin

Abre `Gowin/tang20k_presentacion_eldi_fd73.gprj` con Gowin V1.9.11.03 Education y ejecuta **Run All**. Usa `tang20k_top` como módulo superior, SystemVerilog 2017 y conserva las restricciones del proyecto. El Tcl ofrece el mismo procedimiento desde la raíz del repositorio si `gw_sh` está en el PATH.

```powershell
gw_sh Gowin/build.tcl
```

El script anuncia la ruta del nuevo `.fs` bajo `Gowin/build`. El bitstream incluido corresponde a la compilación principal con cierre a 74,25 MHz, margen de setup de +0,880 ns y cero violaciones de setup y hold. La capa gráfica usa ROM para el texto y el logo. RGB y sincronismos avanzan por las mismas etapas. El código de diagnóstico se cruza como dato estable junto a su validez sincronizada.

## EDA Playground

1. Selecciona **SystemVerilog** y **Icarus Verilog**. Pega [Design.txt](Simulacion/Design.txt) en **Design** y [Testbench.txt](Simulacion/Testbench.txt) en **Testbench**.
2. En opciones de compilación, usa **`-g2012 -s tb_entrega`**. Pulsa **Run**. El caso por defecto comprueba el lector final y la capa visual. Se espera el mensaje `PASS: entrega, lector y presentación`.
3. Para una corrida de módulo, conserva las opciones anteriores y agrega **un** selector `-D` de la tabla. El banco integrado se ejecuta por separado.

| Selector | Prueba |
|---|---|
| `-DELDI_TB_SELECTOR` | Antirrebote, pulsación y cambio en límite de cuadro |
| `-DELDI_TB_CAPTURA` | Memoria y publicación de bloques |
| `-DELDI_TB_TWIDDLE` | ROM de factores de giro |
| `-DELDI_TB_MARIPOSA` | Aritmética de la mariposa |
| `-DELDI_TB_FFT` | FFT de 256 puntos |
| `-DELDI_TB_MAGNITUD` | Raíz cuadrada entera y magnitud |
| `-DELDI_TB_PROCESADOR` | Procesamiento de muestras a espectro |
| `-DELDI_TB_BUFFER` | Doble búfer y cruce de reloj |
| `-DELDI_TB_VIDEO` | Temporización de vídeo 720p |
| `-DELDI_TB_TRAZADOR` | Renderizado de la forma de onda y el espectro |
| `-DELDI_TB_TMDS` | Símbolos de datos y control |
| `-DELDI_TB_INTEGRACION` | ADC, FFT, imagen, S2 y símbolos TMDS de la entrega |

El diseño simulado llega hasta los símbolos TMDS. PLL, divisor y serializadores Gowin se elaboran en el proyecto de la FPGA. Los módulos reutilizados cuentan con resultados previos de EDA Playground. Las pruebas de laboratorio reportadas corresponden a la base FD73 v1. En la versión principal están documentados síntesis, colocación, ruteo y temporización. La corrida en EDA de los bancos específicos y la comprobación del logo ampliado en el monitor quedan pendientes de evidencia.

El informe se puede recompilar desde `Informe` con `tectonic informe_eldi_fft.tex`. Conserva `figuras` junto al archivo LaTeX.

## Orden para subir a GitHub

1. Crea el repositorio y añade a ambos estudiantes como colaboradores.
2. En la raíz del repositorio, sube **el contenido** de `Para_GitHub_ELDI`. Empieza por `README.md` y `.gitignore`, luego `Gowin`, `Programar`, `Simulacion` e `Informe`, respetando las carpetas.
3. Verifica que GitHub muestre el README en la portada y que se puedan abrir el PDF y los dos paneles. Entrega al profesor el enlace del repositorio el día anterior a la evaluación.

Se usó Codex para organizar la implementación, generar ROM y bancos, revisar la compilación y redactar el informe con base en las pruebas aportadas por los estudiantes.
